require 'test_helper'

class Api::UserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

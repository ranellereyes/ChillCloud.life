require 'test_helper'

class Api::SessionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

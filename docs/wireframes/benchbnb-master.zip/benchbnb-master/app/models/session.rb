class Session < ApplicationRecord

end

require 'test_helper'

class Api::UsersControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
